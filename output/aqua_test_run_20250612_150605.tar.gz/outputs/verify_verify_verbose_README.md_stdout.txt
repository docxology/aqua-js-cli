file name README.md.aqua.json
-> reading pure file ./README.md
Checking aqua file: ./README.md.aqua.json
-> reading aqua file ./README.md.aqua.json
 ➡️  1.Verifying Revision: 0xd84c2a49f59d4ec637a77c9e16f46480d24e227d1c350759606c596a3e8725b8
	 📄 Type: File.
	 ✅ ⏺️  Scalar revision verified
  

 ✅ All revisions verified successfully

