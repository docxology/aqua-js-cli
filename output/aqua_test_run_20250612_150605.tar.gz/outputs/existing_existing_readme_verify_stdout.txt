file name README.md.aqua.json
-> reading pure file ./README.md
Checking aqua file: ./README.md.aqua.json
-> reading aqua file ./README.md.aqua.json
✅ All revisions verified successfully

